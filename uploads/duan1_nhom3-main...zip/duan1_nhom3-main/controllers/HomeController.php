<?php 

class HomeController
{
    public function index() {
        // echo "Xưởng thực hành dự án 1-liemthepham";
    }
}