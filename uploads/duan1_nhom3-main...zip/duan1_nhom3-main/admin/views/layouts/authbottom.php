      </div><!-- /.auth-card -->
    </div><!-- /.row -->
  </div><!-- /.container -->

  <!-- Bootstrap JS -->
  <script src="/duan1/admin/assets/js/bootstrap.bundle.min.js"></script>
</body>
</html>
