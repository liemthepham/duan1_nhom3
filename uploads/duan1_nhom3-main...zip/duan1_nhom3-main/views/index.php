<!DOCTYPE html>
<html lang="vi">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cửa hàng điện tử</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">

    <link rel="stylesheet" href="/duan1//public/css/cusstom.css">
    <style>

    </style>
</head>

<body>

    <?php
    $user = $_SESSION['user'] ?? null;
    ?>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark sticky-top">
        <div class="container">
            <a class="navbar-brand" href="index.php?act=home">
                <i class="fas fa-mobile-alt"></i> TechStore
            </a>
            <button class="navbar-toggler" type="button"
                data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse" id="navbarNav">
                <!-- menu chính -->
                <ul class="navbar-nav me-auto">
                    <li class="nav-item"><a class="nav-link" href="index.php?act=home">Trang chủ</a></li>
                    <li class="nav-item"><a class="nav-link" href="index.php?act=products">Sản phẩm</a></li>
                    <li class="nav-item"><a class="nav-link" href="index.php?act=contact">Liên hệ</a></li>
                </ul>

                <!-- phần bên phải -->
                <ul class="navbar-nav ms-auto align-items-center">
                    <!-- icon giỏ -->
                    <li class="nav-item me-3 position-relative">
                        <a class="btn btn-outline-light" href="index.php?act=cart">
                            <i class="fas fa-shopping-cart"></i>
                        </a>
                        <?php if (!empty($_SESSION['cart'])): ?>
                            <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger">
                                <?= count($_SESSION['cart']) ?>
                            </span>
                        <?php endif; ?>
                    </li>
                    <?php if (!empty($_SESSION['flash'])): ?>
                        <?php
                        $f = $_SESSION['flash'];
                        unset($_SESSION['flash']);
                        ?>
                        <div class="container mt-3">
                            <div class="alert alert-<?= $f['type'] ?> alert-dismissible fade show" role="alert">
                                <?= htmlspecialchars($f['message']) ?>
                                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Đóng"></button>
                            </div>
                        </div>
                    <?php endif; ?>
                    <!-- nếu chưa login -->
                    <?php if (!$user): ?>
                        <li class="nav-item d-flex">
                            <a href="index.php?act=login"
                                class="btn btn-outline-light me-2 px-3 py-1">
                                Đăng nhập
                            </a>
                            <a href="index.php?act=register"
                                class="btn btn-primary px-3 py-1">
                                Đăng ký
                            </a>
                        </li>

                        <!-- nếu đã login -->
                    <?php else: ?>
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle d-flex align-items-center"
                                href="#" id="userMenu" data-bs-toggle="dropdown">
                                <i class="fas fa-user-circle me-1"></i>
                                <?= htmlspecialchars($user['TenDangNhap'] ?? $user['Email']) ?>
                            </a>
                            <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="userMenu">
                                <?php if (($user['VaiTro'] ?? '') === 'admin'): ?>
                                    <li><a class="dropdown-item" href="admin/index.php">Dashboard Admin</a></li>
                                    <li>
                                        <hr class="dropdown-divider">
                                    </li>
                                <?php endif; ?>
                                <li><a class="dropdown-item" href="index.php?act=logout">Đăng xuất</a></li>
                            </ul>
                        </li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
    </nav>




    <!-- BANNER – BOOTSTRAP CAROUSEL -->
    <div id="bannerCarousel" class="carousel slide" data-bs-ride="carousel" data-bs-interval="3500">
        <!-- 1) Indicators (đốm nhỏ) -->
        <div class="carousel-indicators">
            <button type="button" data-bs-target="#bannerCarousel" data-bs-slide-to="0" class="active" aria-current="true"></button>
            <button type="button" data-bs-target="#bannerCarousel" data-bs-slide-to="1"></button>
            <button type="button" data-bs-target="#bannerCarousel" data-bs-slide-to="2"></button>
        </div>

        <!-- 2) Wrapper cho các slide -->
        <div class="carousel-inner">

            <!-- Slide 1 -->
            <div class="carousel-item active">
                <img src="public/images/banner1.png" class="d-block w-100 banner-img" alt="Hotsale Mùa Hè 1">
                <div class="carousel-caption d-none d-md-block">
                    <h1 class="display-4">Hotsale Mùa Hè</h1>
                    <p class="lead">Ưu đãi lớn, quà tặng hấp dẫn</p>
                    <a href="index.php?act=product-list" class="btn btn-primary btn-lg">Khám phá</a>
                </div>
            </div>

            <!-- Slide 2 -->
            <div class="carousel-item">
                <img src="public/images/banner2'.jpg" class="d-block w-100 banner-img" alt="Hotsale Mùa Hè 2">
                <div class="carousel-caption d-none d-md-block">
                    <h1 class="display-4">Flash Sale Đỉnh Cao</h1>
                    <p class="lead">Giảm sâu lên tới 50%</p>
                    <a href="index.php?act=product-list" class="btn btn-primary btn-lg">Mua ngay</a>
                </div>
            </div>

            <!-- Slide 3 -->
            <div class="carousel-item">
                <img src="public/images/banner3.jpg" class="d-block w-100 banner-img" alt="Hotsale Mùa Hè 3">
                <div class="carousel-caption d-none d-md-block">
                    <h1 class="display-4">Combo Siêu Tiết Kiệm</h1>
                    <p class="lead">Mua 2 tặng 1 – Chỉ hôm nay</p>
                    <a href="index.php?act=product-list" class="btn btn-primary btn-lg">Xem chi tiết</a>
                </div>
            </div>

        </div>

        <!-- 3) Prev / Next controls -->
        <button class="carousel-control-prev" type="button" data-bs-target="#bannerCarousel" data-bs-slide="prev">
            <span class="carousel-control-prev-icon"></span>
            <span class="visually-hidden">Trước</span>
        </button>
        <button class="carousel-control-next" type="button" data-bs-target="#bannerCarousel" data-bs-slide="next">
            <span class="carousel-control-next-icon"></span>
            <span class="visually-hidden">Sau</span>
        </button>
    </div>


    <!-- DANH MỤC -->
    <div class="container py-5">
        <h2 class="text-center mb-4">Danh mục sản phẩm</h2>
        <div class="row g-4">
            <?php
            foreach ($categories as $cat): ?>
                <div class="col-md-3">
                    <div class="category-item text-center">
                        <a href="index.php?act=home&category_id=<?php echo $cat['MaDanhMuc']; ?>" class="text-decoration-none text-dark">
                            <i class="fas fa-<?php /* Cần thêm cột icon vào bảng danhmuc hoặc mapping */ echo 'mobile-alt'; ?> fa-2x mb-2"></i>
                            <h5><?php echo htmlspecialchars($cat['TenDanhMuc']); ?></h5>
                        </a>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>

    <!-- SẢN PHẨM BÁN CHẠY -->
    <div class="container mb-5">
        <h2 class="text-center mb-4">Sản phẩm bán chạy</h2>
        <div class="row g-4">
            <?php foreach ($products as $product): ?>
                <div class="col-md-3">
                    <div class="card h-100 border-0 shadow-sm product-card">
                        <img src="admin/uploads/<?php echo htmlspecialchars($product['AnhDaiDien']); ?>"
                            class="card-img-top product-image"
                            alt="<?php echo htmlspecialchars($product['TenSanPham']); ?>">
                        <div class="card-body d-flex flex-column">
                            <h5 class="card-title mb-2">
                                <?php echo htmlspecialchars($product['TenSanPham']); ?>
                            </h5>
                            <p class="text-danger fw-bold mb-3">
                                <?php echo number_format($product['Gia']); ?> VNĐ
                            </p>
                            <div class="mt-auto d-flex justify-content-between">
                                <a href="index.php?act=product-detail&id=<?php echo $product['MaSanPham']; ?>"
                                    class="btn btn-primary btn-sm">Chi tiết</a>
                                <form action="index.php?act=add-to-cart" method="POST" style="display:inline;">
                                    <input type="hidden" name="product_id"
                                        value="<?php echo $product['MaSanPham']; ?>">
                                    <button type="submit" class="btn btn-success btn-sm">
                                        <i class="fas fa-cart-plus"></i> Thêm vào giỏ
                                    </button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>

        </div>
    </div>

    <!-- Pagination -->
    <nav aria-label="Page navigation">
        <ul class="pagination justify-content-center">
            <?php if ($current_page > 1): ?>
                <li class="page-item">
                    <a class="page-link" href="index.php?act=home&page=<?php echo $current_page - 1; ?>" aria-label="Previous">
                        <span aria-hidden="true">&laquo;</span>
                    </a>
                </li>
            <?php endif; ?>

            <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                <li class="page-item <?php echo ($i == $current_page) ? 'active' : ''; ?>">
                    <a class="page-link" href="index.php?act=home&page=<?php echo $i; ?>"><?php echo $i; ?></a>
                </li>
            <?php endfor; ?>

            <?php if ($current_page < $total_pages): ?>
                <li class="page-item">
                    <a class="page-link" href="index.php?act=home&page=<?php echo $current_page + 1; ?>" aria-label="Next">
                        <span aria-hidden="true">&raquo;</span>
                    </a>
                </li>
            <?php endif; ?>
        </ul>
    </nav>

    <!-- SẢN PHẨM GỢI Ý -->
    <div class="container mb-5">
        <h2 class="text-center mb-4">Sản phẩm gợi ý</h2>
        <div class="row g-4">
            <?php /* Cần lấy dữ liệu sản phẩm gợi ý từ database */ ?>
            <?php for ($i = 1; $i <= 4; $i++): // Tạm thời hiển thị dữ liệu mẫu 
            ?>
                <div class="col-md-3">
                    <div class="card h-100 product-card border-0 shadow-sm">
                        <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQWZ5IzzJCuIb0UjqEcCBcQZoivGa4zAy6A-g&s" class="card-img-top" alt="Sản phẩm">
                        <div class="card-body d-flex flex-column">
                            <h5 class="card-title">Samsung Galaxy S23 Ultra</h5>
                            <p class="text-danger fw-bold">24.990.000đ</p>
                            <a href="#" class="btn btn-outline-primary mt-auto">Mua ngay</a>
                        </div>
                    </div>
                </div>
            <?php endfor; ?>
        </div>
    </div>

    <!-- FOOTER -->
    <footer class="pt-5 pb-3">
        <div class="container">
            <div class="row">
                <div class="col-md-4">
                    <h5>Về chúng tôi</h5>
                    <p>Cửa hàng điện tử uy tín, chất lượng</p>
                </div>
                <div class="col-md-4">
                    <h5>Liên hệ</h5>
                    <p>Email: contact@example.com</p>
                    <p>Điện thoại: 0123 456 789</p>
                </div>
                <div class="col-md-4">
                    <h5>Theo dõi chúng tôi</h5>
                    <div class="d-flex">
                        <a href="#" class="text-light me-2"><i class="fab fa-facebook"></i></a>
                        <a href="#" class="text-light me-2"><i class="fab fa-twitter"></i></a>
                        <a href="#"><i class="fab fa-instagram"></i></a>
                    </div>
                </div>
            </div>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        window.addEventListener('scroll', () => {
            document.querySelector('.navbar')
                .classList.toggle('scrolled', window.scrollY > 50);
        });
    </script>
</body>

</html>